
import pandas as pd
from utils.news_scraper import NewsScraper
from utils.news_comparison import NewsComparison

def main():
    # Initialize components
    scraper = NewsScraper()
    comparator = NewsComparison()
    
    # Get news articles
    print("Fetching news articles...")
    articles = []
    queries = ["cybersecurity breach", "malware attack", "phishing campaign", 
               "ransomware attack", "zero day vulnerability"]
    
    for query in queries:
        results = scraper.fetch_articles(query, page_size=5)
        articles.extend(results)
    
    # Create news dataframe
    news_df = pd.DataFrame(articles)
    news_df['timestamp'] = pd.to_datetime(news_df['publishedAt'])
    news_df = news_df[['title', 'description', 'timestamp']]
    
    # Save raw news data
    news_df.to_csv('scraped_news.csv', index=False)
    print("News data saved to scraped_news.csv")
    
    # Load and process GPT data (assuming it exists)
    try:
        gpt_df = pd.read_csv('gpt_data.csv')
    except FileNotFoundError:
        print("Warning: gpt_data.csv not found, creating sample data...")
        gpt_df = pd.DataFrame({
            'content': ['Sample threat data'],
            'timestamp': [pd.Timestamp.now()]
        })
    
    # Process and tag both datasets
    print("\nTagging news articles...")
    tagged_news = comparator.process_news_data(news_df)
    print("Tagging GPT data...")
    tagged_gpt = comparator.process_gpt_data(gpt_df)
    
    # Compare datasets
    print("\nComparing datasets...")
    comparison = comparator.compare_datasets(tagged_news, tagged_gpt)
    
    # Save results
    # Export the comparison data
    success, message = comparator.export_comparison(comparison)
    print("\nComparison results:")
    print(comparison.to_string())
    print(f"\n{message}")

if __name__ == "__main__":
    main()
