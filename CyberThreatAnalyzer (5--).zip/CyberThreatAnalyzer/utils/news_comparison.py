import pandas as pd
from utils.gpt_helper import GPTHelper


class NewsComparison:

    def __init__(self):
        self.gpt = GPTHelper()

    def tag_content(self, text):
        prompt = f"""Classify this cybersecurity text into ONE of these categories:
        - Phishing
        - Malware
        - Data Breach
        - Cloud Security
        - Zero Day
        - Ransomware
        - Network Security
        - Other

        Text: {text}

        Return ONLY the category name, nothing else."""

        response = self.gpt._send_request(prompt)
        if isinstance(response, dict) and response.get('status') == 'success':
            return response.get('data', {}).get('content',
                                                'Unclassified').strip()
        return 'Unclassified'

    def process_news_data(self, news_df):
        # Tag each article based on title and description
        news_df['tag'] = news_df.apply(
            lambda x: self.tag_content(f"{x['title']} {x['description']}"),
            axis=1)
        return news_df

    def process_gpt_data(self, gpt_df):
        # Tag GPT data based on content
        gpt_df['tag'] = gpt_df['content'].apply(self.tag_content)
        return gpt_df

    def compare_datasets(self, news_df, gpt_df):
        # Group by tags and count occurrences
        news_tags = news_df.groupby('tag').size().reset_index(
            name='news_count')
        gpt_tags = gpt_df.groupby('tag').size().reset_index(name='gpt_count')

        # Merge the tag counts
        comparison = pd.merge(news_tags, gpt_tags, on='tag',
                              how='outer').fillna(0)
        comparison[['news_count',
                    'gpt_count']] = comparison[['news_count',
                                                'gpt_count']].astype(int)

        # Calculate differences
        comparison[
            'difference'] = comparison['news_count'] - comparison['gpt_count']

        return comparison.sort_values('difference', ascending=False)
